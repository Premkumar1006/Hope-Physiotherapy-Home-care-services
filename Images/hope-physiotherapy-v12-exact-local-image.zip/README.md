# Hope Physiotherapy – V12

This is the V12 website design approved for the Hope Physiotherapy website.

Files:
- `index.html` – complete page structure/content
- `style.css` – complete V12 styling

Important:
- The hero physiotherapy image is embedded inside `index.html`, so it does not need a separate hero image file.
- Service-card images use remote Pexels image URLs and therefore need internet access.
- The booking form opens WhatsApp to +91 88979 78832.
- Phone links use +91 88979 78832.
- Google review cards are intentionally not fake reviews; they are placeholders until the real Google Business Profile reviews are connected.

GitHub/Vercel:
1. Replace the existing root `index.html` with this `index.html`.
2. Upload `style.css` to the same root folder.
3. Commit/push to the `main` branch.
4. Vercel should redeploy automatically if the existing project is connected to GitHub.


## V12 exact hero image
The approved V12 hero/Why-section image is stored locally at `Images/hero-home-physiotherapy.png`. Both V12 image placements use this local file so GitHub/Vercel will display the same image as the approved V12 design.
